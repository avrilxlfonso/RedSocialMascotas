@com.mycompany.myapp.SharedKernel
package com.mycompany.myapp.shared.collection;
