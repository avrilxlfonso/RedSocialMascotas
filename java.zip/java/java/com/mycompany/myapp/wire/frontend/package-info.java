@com.mycompany.myapp.SharedKernel
package com.mycompany.myapp.wire.frontend;
